package LibSys;

public class Run {
    public static void main(String[] args) {
        MainInterface m = new MainInterface();
        m.mainInter();
    }
}
